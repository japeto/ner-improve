def construir_test_mayus():
    archivoTestA = open("esp.testa", "r")
    archivoTestB = open("esp.testb", "r")
    new_test_a = open("esp.testaMayus", "w")
    new_test_b = open("esp.testbMayus", "w")

    lineas_test_a = archivoTestA.readlines()
    lineas_test_b = archivoTestB.readlines()

    for line in lineas_test_a:
        array = line.replace("\n", "").split(" ")
        feature = 0
        if len(array) == 1:
            new_test_a.write("\n")
        else:
            if array[0][:1].isupper():
                if array[2][:2] == 'B-'or array[2][:2] == 'I-' or array[2][:2] == 'O-':
                    feature = 1

            new_test_a.write(array[0] + " " + array[1] + " " + str(feature) + " " + array[2] + "\n")

    for line in lineas_test_b:
        array = line.replace("\n", "").split(" ")
        feature = 0
        if len(array) == 1:
            new_test_b.write("\n")
        else:
            if array[0][:1].isupper():
                if array[2][:2] == 'B-'or array[2][:2] == 'I-' or array[2][:2] == 'O-':
                    feature = 1

            new_test_b.write(array[0] + " " + array[1] + " " + str(feature) + " " + array[2] + "\n")

    new_test_a.close()
    new_test_b.close()
    archivoTestA.close()
    archivoTestB.close()


def construir_test_treshold(umbral):
    archivoTestA = open("esp.testaMayus", "r")
    archivoTestB = open("esp.testbMayus", "r")
    new_test_a = open("esp.testaTreshold", "w")
    new_test_b = open("esp.testbTreshold", "w")

    lineas_test_a = archivoTestA.readlines()
    lineas_test_b = archivoTestB.readlines()

    for line in lineas_test_a:
        array = line.replace("\n", "").split(" ")
        feature = 0
        if len(array) == 1:
            new_test_a.write("\n")
        else:
            palabra=array[0]
            postag=array[1]
            mayus=array[2]
            ne=array[3]
            if len(palabra) >= umbral:
                feature = 1
            new_test_a.write(palabra + " " + postag + " " + mayus + " " + str(feature) + " " + ne + "\n")

    for line in lineas_test_b:
        array = line.replace("\n", "").split(" ")
        feature = 0
        if len(array) == 1:
            new_test_a.write("\n")
        else:
            palabra=array[0]
            postag=array[1]
            mayus=array[2]
            ne=array[3]
            if len(palabra) >= umbral:
                feature = 1
            new_test_b.write(palabra + " " + postag + " " + mayus + " " + str(feature) + " " + ne + "\n")

    new_test_a.close()
    new_test_b.close()
    archivoTestA.close()
    archivoTestB.close()

def construir_test_inicio_sentencia():
    archivoTestA = open("esp.testaTreshold", "r")
    archivoTestB = open("esp.testbTreshold", "r")
    new_test_a = open("esp.testaSentence", "w")
    new_test_b = open("esp.testbSentence", "w")

    lineas_test_a = archivoTestA.readlines()
    lineas_test_b = archivoTestB.readlines()
    count = 0
    for line in lineas_test_a:
        array = line.replace("\n", "").split(" ")
        feature = 0
        if len(array) == 1:
			new_test_a.write("\n")

        elif len(array) > 1:
            palabra = array[0]
            postag = array[1]
            mayus = array[2]
            tresh = array[3]
            ne = array[4]

            if count == 0:
                feature = 1
            elif count > 0:
                if lineas_test_a[count - 1].split(" ") == ["'\n"] and postag != "Fg":
                    feature = 1
            new_test_a.write(palabra + " " + postag + " " + mayus + " " + tresh + " " + str(feature) + " " + ne + "\n")

    for line in lineas_test_b:
        array = line.replace("\n", "").split(" ")
        feature = 0
        
        if len(array) == 1:
			new_test_b.write("\n")

        elif len(array) > 1:
            palabra = array[0]
            postag = array[1]
            mayus = array[2]
            tresh = array[3]
            ne = array[4]

            if count == 0:
                feature = 1
            elif count > 0:
                if lineas_test_a[count - 1].split(" ") == ["'\n"] and postag != "Fg":
                    feature = 1
            new_test_b.write(palabra + " " + postag + " " + mayus + " " + tresh + " " + str(feature) + " " + ne + "\n")

    new_test_a.close()
    new_test_b.close()
    archivoTestA.close()
    archivoTestB.close()


def main():
    umbral = 5
    #construir_test_mayus()
    #construir_test_treshold(umbral)
    construir_test_inicio_sentencia()

main()
