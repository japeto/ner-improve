import os
import sys    # sys.setdefaultencoding is cancelled by site.py
reload(sys)    # to re-enable sys.setdefaultencoding()
sys.setdefaultencoding('utf-8')

def ConstruirTrainConll1_0():
	archivo=open('esp.train', 'r')
	nuevoTrain=open("ConllTrain1_0", 'w')
	lineasEsp=archivo.readlines()
	for line in lineasEsp:
		arrayLine=line.replace("\n",'').split(" ")
		valor =0
		if len(arrayLine)==1:
			nuevoTrain.write("\n")
		else:
			if arrayLine[0][:1].isupper():
				if arrayLine[2][:2]=='B-'or arrayLine[2][:2]=='I-' or arrayLine[2][:2]=='O-':
					valor=1
			nuevoTrain.write(arrayLine[0] + " " + arrayLine[1] + " " + str(valor) + " "+ arrayLine[2]+"\n")
	nuevoTrain.close()
	archivo.close
	
#ConstruirTrainConll1_0()
treshold=5
def TrainTreshold(umbral):
	archivo=open("Training/ConllTrain1_0", "r")
	nuevoArchivo=open("Training/ConllTrainTreshold.txt","w")
	lineasTrain0=archivo.readlines()
	for linea in lineasTrain0:
		array=linea.replace("\n", "").split(" ")
		#print array
		valor=0
		if  len(array) == 1: 
			nuevoArchivo.write("\n")
		else:
			palabra=array[0]
			posTag=array[1]
			mayus=array[2]
			etiqueta=array[3]
			if len(palabra) >= umbral:
				valor = 1
			
			nuevoArchivo.write(palabra + " " + posTag+ " " + mayus + " " + str(valor)+" "+ etiqueta + "\n")
		
	archivo.close()
	nuevoArchivo.close() 	
			
#TrainTreshold(treshold)

def TrainInicioSentencia():
	archivo=open("Training/ConllTrainTreshold.txt", "r")
	nuevoArchivo=open("Training/ConllTrainSentence.txt", "w")
	lineasTrain=archivo.readlines()
	count=0
	for linea in lineasTrain:
		array=linea.replace("\n", "").split(" ")
		valor=0
		
		
		if  len(array) > 1:
			palabra=array[0]
			posTag=array[1]
			mayus=array[2]
			tamanio=array[3]
			etiqueta=array[4]
			
			if count == 0:
				valor= 1
			elif count > 0:
				
				if lineasTrain[count-1].split(" ")== ["\n"] and posTag != "Fg":
					valor =1
			nuevoArchivo.write(palabra + " " + posTag+ " " + mayus + " " + tamanio +" " + str(valor)+" "+ etiqueta + "\n")

		elif linea.split(" ")==["\n"]:
			nuevoArchivo.write("\n")
			
		
		
		#if len(array) > 1:
		#	palabra=array[0]
		#	posTag=array[1]
		#	mayus=array[2]
		#	tamanio=array[3]
		#	etiqueta=array[4]
		#	if count == 0:
		#		valor=1
		#	elif count > 0:
		#		if linea.split(" ") == [" "]:
		#			tagAnterior=lineasTrain[count-1].split(" ")[0]
		#			if tagAnterior == "\n":
		#				valor =1
		#	nuevoArchivo.write(palabra + " " + posTag+ " " + mayus + " " + tamanio +" " + str(valor)+" "+ etiqueta + "\n")
		
		count+=1
#TrainInicioSentencia()

def palabra_ner():
	archivo=open('esp.train', 'r')
	salida = open('ner.train','w')
	lineasEsp=archivo.readlines()
	for line in lineasEsp:
		arrayLine=line.replace("\n",'').split(" ")
		if len(arrayLine)==1:
			salida.write("\n")
		else:
			salida.write(arrayLine[2] + "\n")
		
palabra_ner()	
	
			
	
		
